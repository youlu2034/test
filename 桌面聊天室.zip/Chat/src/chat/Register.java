package chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.json.JSONObject;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.JTree;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField account;
	private JPasswordField password;
	private JPasswordField repassword;
	private JTextField email;
	private final Action action = new SwingAction();
	public static int boxWidth=355;
	//ע������
	public static int boxHeight=495;
	//ע���߶�
	
	JLabel account_hint = new JLabel("\u8D26\u53F7\u4E3A6-12\u4F4D\u6570\u5B57");
	JLabel password_hint = new JLabel("8~18\u4F4D\u5B57\u6BCD\u6570\u5B57\u7EC4\u5408");
	JLabel repassword_hint = new JLabel("\u8BF7\u518D\u8F93\u5165\u4E00\u904D\u5BC6\u7801");
	JLabel email_hint = new JLabel("\u90AE\u7BB1\u7528\u4E8E\u627E\u56DE\u5BC6\u7801");
	static Register frame = new Register();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setResizable(false);
					frame.setTitle("ע���˺�");
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds((Login.screenWidth-boxWidth)/2, (Login.screenHeight-boxHeight)/2, boxWidth, boxHeight);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel account_label = new JLabel("\u8D26\u53F7\uFF1A");
		account_label.setHorizontalAlignment(SwingConstants.RIGHT);
		account_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account_label.setBounds(85, 45, 50, 30);
		contentPane.add(account_label);
		
		account = new JTextField();
		account.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account.setBounds(135, 45, 120, 30);
		contentPane.add(account);
		account.setColumns(10);
		
		
		
		account_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account_hint.setBounds(135, 75, 120, 30);
		contentPane.add(account_hint);
		
		JLabel password_label = new JLabel("\u5BC6\u7801\uFF1A");
		password_label.setHorizontalAlignment(SwingConstants.RIGHT);
		password_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password_label.setBounds(85, 108, 50, 30);
		contentPane.add(password_label);
		
		password = new JPasswordField();
		password.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password.setBounds(135, 105, 120, 30);
		contentPane.add(password);
		

		password_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password_hint.setBounds(135, 135, 120, 30);
		contentPane.add(password_hint);
		
		JLabel repassword_label = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		repassword_label.setHorizontalAlignment(SwingConstants.RIGHT);
		repassword_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		repassword_label.setBounds(75, 165, 60, 30);
		contentPane.add(repassword_label);
		
		repassword = new JPasswordField();
		repassword.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		repassword.setBounds(135, 165, 120, 30);
		contentPane.add(repassword);
		
		
		repassword_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		repassword_hint.setBounds(135, 195, 120, 30);
		contentPane.add(repassword_hint);
		
		JLabel email_label = new JLabel("\u90AE\u7BB1\uFF1A");
		email_label.setHorizontalAlignment(SwingConstants.RIGHT);
		email_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		email_label.setBounds(85, 225, 50, 30);
		contentPane.add(email_label);
		
		email = new JTextField();
		email.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		email.setColumns(10);
		email.setBounds(135, 225, 120, 30);
		contentPane.add(email);
		
		
		email_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		email_hint.setBounds(135, 255, 120, 30);
		contentPane.add(email_hint);
		
		JRadioButton agree = new JRadioButton("\u540C\u610F\u4F7F\u7528\u534F\u8BAE");
		agree.setEnabled(false);
		agree.setSelected(true);
		agree.setOpaque(false);
		agree.setFocusPainted(false);
		agree.setBounds(135, 290, 120, 23);
		contentPane.add(agree);
		
		JButton btnNewButton = new JButton("\u6CE8\u518C");
		btnNewButton.setAction(action);
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		btnNewButton.setBounds(85, 340, 170, 40);
		btnNewButton.setFocusPainted(false);
		contentPane.add(btnNewButton);
		
		/*
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon("img/Penguin_137.64383561644px_546496_easyicon.net.png"));
		lblNewLabel_2.setBounds(189, 34, 150, 170);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("img/register.jpg"));
		lblNewLabel_1.setBounds(0, 0, 346, 461);
		contentPane.add(lblNewLabel_1);
		*/
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "ע��");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			String user_zh= account.getText().trim();
			
			String user_pwd = new String(password.getPassword());
			
			String user_repwd = new String(repassword.getPassword());
			
			String user_email = email.getText().trim();
			
			if(user_zh.matches(Login.zh)) {
				account_hint.setForeground(Color.black);
				if(user_pwd.matches(Login.pwd)) {
					password_hint.setForeground(Color.black);
					if(user_repwd.equals(user_pwd)) {
						repassword_hint.setText("��������һ������");
						repassword_hint.setForeground(Color.black);
						if(user_email.matches(Login.email)) {
							email_hint.setText("���������һ�����");
							email_hint.setForeground(Color.black);
							JSONObject object = new JSONObject();
						    object.put("action",2);
						    object.put("user_zh",user_zh);
						    object.put("user_pwd",user_pwd);
						    object.put("user_email",user_email);
						    object.put("user_ip",Login.get_ip());
						    object.put("user_port",Connect.port);
						    JSONObject object_post = new JSONObject();
						    object_post = Connect.post(object);
						    if(object_post != null) {
						    	if(object_post.get("status").toString().equals("true")) {
									//ע��ɹ���
									Alert.main("ע��ɹ���");
									frame.dispose();
								}else {
									if(object_post.get("massage") != null) {
										account_hint.setText(object_post.get("massage").toString());
										account_hint.setForeground(Color.RED);
									}else {
										account_hint.setText("����������");
										account_hint.setForeground(Color.RED);
									}
								}
						    }else {
						    	account_hint.setText("����������");
								account_hint.setForeground(Color.RED);
						    }
							
						}else {
							email_hint.setText("��������ȷ������");
							email_hint.setForeground(Color.RED);
						}
					}else {
						repassword_hint.setText("�����������벻һ��");
						repassword_hint.setForeground(Color.RED);
					}
				}else {
					password_hint.setText("8~18λ��ĸ�������");
					password_hint.setForeground(Color.RED);
				}
			}else {
				account_hint.setText("�˺�Ϊ6~12λ����");
				account_hint.setForeground(Color.RED);
			}

		}

	}
}
