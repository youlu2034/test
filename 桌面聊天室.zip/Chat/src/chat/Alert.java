package chat;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Alert extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private final Action action = new SwingAction();
	static Alert dialog = new Alert();
	private JLabel text_label = new JLabel("");
	private JButton btnNewButton = new JButton("�ر�");

	public int boxWidth=300;
	//��½�����
	public int boxHeight=160;
	//��½��߶�
	public static int i=3;
	/**
	 * Launch the application.
	 */
	public static void main(String content) {
		try {
			i=3;
			//Alert dialog = new Alert();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			dialog.setResizable(false);
			dialog.text_label.setText(content);
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
		        public void run() {
		        	dialog.btnNewButton.setText("�رգ�"+i+"s)");
		            i--;
		            if(i < 0) {
		            	this.cancel();
		            	dialog.dispose();
		            }
		        }
			}, 0 , 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Alert() {
		setBounds((Login.screenWidth-boxWidth)/2, (Login.screenHeight-boxHeight)/2, boxWidth, boxHeight);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			text_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
			text_label.setHorizontalAlignment(SwingConstants.CENTER);
			text_label.setBounds(50, 20, 184, 30);
			contentPanel.add(text_label);
		}
		{
			
			btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
			btnNewButton.setAction(action);
			btnNewButton.setBounds(92, 80, 100, 30);
			btnNewButton.setFocusPainted(false);
			contentPanel.add(btnNewButton);
		}
	}

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "�ر�");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			dialog.dispose();
		}
	}
}
