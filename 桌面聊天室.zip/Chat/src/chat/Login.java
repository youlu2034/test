package chat;

import java.awt.BorderLayout;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.json.JSONObject;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import java.awt.SystemColor;
import java.awt.Toolkit;

import java.awt.event.MouseListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;


public class Login extends JDialog {

	public static int screenWidth=Login.getsize().width;
	//��Ļ����
	public static int screenHeight=Login.getsize().height;
	//��Ļ�߶�
	public static int boxWidth=450;
	//��½�����
	public static int boxHeight=300;
	//��½��߶�
	public static String zh = "[0-9]\\d{6,12}";
	public static String pwd = "^(?=.*[0-9])(?=.*[a-zA-Z])(.{8,18})$";
	public static String email = "\\w[-\\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\\.)+[A-Za-z]{2,14}";
	public static String code = "[0-9A-Z]{6}";
	public static String ip="((25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))";
	public static String port="([0-9]|[1-9]\\d{1,3}|[1-5]\\d{4}|6[0-4]\\d{4}|65[0-4]\\d{2}|655[0-2]\\d|6553[0-5])";

	private final JPanel contentPanel = new JPanel();
	private JTextField account;
	private JPasswordField password;
	private JLabel register = new JLabel("\u6CE8\u518C\u8D26\u53F7");
	private JLabel reset = new JLabel("\u627E\u56DE\u5BC6\u7801");
	private JLabel login = new JLabel("\u767B\u9646");
	JLabel account_hint = new JLabel("");
	JLabel password_hint = new JLabel("");
	static Login dialog = new Login();
	public static int usr_id=7;
	public static String usr_name="";
	private final JLabel lblNewLabel = new JLabel("");
	public static Dimension getsize(){
		Toolkit kit = Toolkit.getDefaultToolkit();
        return kit.getScreenSize();
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setTitle("��½");
			dialog.setResizable(false);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Login() {
		
		setBounds((screenWidth-boxWidth)/2, (screenHeight-boxHeight)/2, boxWidth, boxHeight);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(240, 240, 240));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel accountlabel = new JLabel("\u8D26\u53F7:");
		accountlabel.setHorizontalAlignment(SwingConstants.CENTER);
		accountlabel.setForeground(Color.BLACK);
		accountlabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		accountlabel.setBounds(105, 45, 40, 30);
		contentPanel.add(accountlabel);
		
		
		account_hint.setForeground(new Color(255, 102, 255));
		account_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account_hint.setBounds(155, 74, 150, 30);
		contentPanel.add(account_hint);
		{
			JLabel passwordlabel = new JLabel("\u5BC6\u7801:");
			passwordlabel.setHorizontalAlignment(SwingConstants.CENTER);
			passwordlabel.setForeground(Color.BLACK);
			passwordlabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
			passwordlabel.setBounds(105, 105, 40, 30);
			contentPanel.add(passwordlabel);
		}
		
		
		password_hint.setForeground(new Color(255, 102, 255));
		password_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password_hint.setBounds(155, 134, 150, 30);
		contentPanel.add(password_hint);
		
		account = new JTextField();
		account.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account.setToolTipText("\u8D26\u53F7");
		account.setOpaque(true);
		account.setBackground(new Color(255, 255, 255));
		account.setBounds(155, 45, 150, 30);
		contentPanel.add(account);
		account.setColumns(10);
		
		password = new JPasswordField();
		password.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password.setBounds(155, 105, 150, 30);
		password.setOpaque(true);
		password.setBackground(new Color(255, 255, 255));
		contentPanel.add(password);
		
		
		register.addMouseListener(new toRegister());	
		register.setOpaque(false);
		register.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		register.setForeground(SystemColor.activeCaptionBorder);
		register.setBounds(307, 45, 60, 30);
		contentPanel.add(register);
		
			
		reset.addMouseListener(new toReset());	
		reset.setForeground(SystemColor.activeCaptionBorder);
		reset.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		reset.setBounds(307, 105, 60, 30);
		contentPanel.add(reset);
		
		
		login.addMouseListener(new toLogin());	
		login.setOpaque(true);
		login.setForeground(Color.BLACK);
		login.setBackground(new Color(255, 255, 255,125));
		login.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255,10), 5, true));
		login.setHorizontalAlignment(SwingConstants.CENTER);
		login.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		login.setBounds(120, 170, 200, 40);
		contentPanel.add(login);
		
		lblNewLabel.addMouseListener(new toSet());
		lblNewLabel.setIcon(new ImageIcon("img/e1.png"));
		lblNewLabel.setBounds(400, 231, 30, 30);
		
		contentPanel.add(lblNewLabel);
		

		/*
		JLabel qe = new JLabel("");
		qe.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		qe.setIcon(new ImageIcon("img/Penguin_137.64383561644px_546496_easyicon.net.png"));
		qe.setBounds(10, 30, 140, 148);
		contentPanel.add(qe);
		
		JLabel bk = new JLabel("");
		bk.setIcon(new ImageIcon("img/bk.png"));
		bk.setBounds(0, 0, 434, 262);
		contentPanel.add(bk);
		*/
	}

	public class toSet implements MouseListener{
		public toSet(){}
		
		public void mouseClicked(MouseEvent e) {
			Set.main(null);
		}
		public void mouseEntered(MouseEvent e) {
			}
		public void mouseExited(MouseEvent e) {
			}
		public void mousePressed(MouseEvent e) {
			
		}
		public void mouseReleased(MouseEvent e) {
		
		}
		
	}
	
	public class toRegister implements MouseListener{
		public toRegister(){}
		
		public void mouseClicked(MouseEvent e) {
			//System.out.println("ע��");
			//Alert.main(null);
			Register.main(null);
		}
		public void mouseEntered(MouseEvent e) {
			register.setForeground(new Color(0, 0, 0));
			}
		public void mouseExited(MouseEvent e) {
			register.setForeground(SystemColor.activeCaptionBorder);
			}
		public void mousePressed(MouseEvent e) {
			
		}
		public void mouseReleased(MouseEvent e) {
		
		}
		
	}
	public class toReset implements MouseListener{
		public toReset(){}
		
		public void mouseClicked(MouseEvent e) {
			//System.out.println("�һ�����");
			Reset.main(null);
			//dialog.dispose();
		}
		public void mouseEntered(MouseEvent e) {
			reset.setForeground(new Color(0, 0, 0));
		}
		public void mouseExited(MouseEvent e) {
			reset.setForeground(SystemColor.activeCaptionBorder);
		}
		public void mousePressed(MouseEvent e) {
		}
		public void mouseReleased(MouseEvent e) {
		}
		
	}
	public class toLogin implements MouseListener{
		public toLogin(){}
		public void mouseClicked(MouseEvent e) {
			
			String user_zh= account.getText().trim();
			
			String user_pwd = new String(password.getPassword());
			if(user_zh.matches(zh)) {
				if(user_pwd.matches(pwd)) {
					JSONObject object = new JSONObject();
				    object.put("action",1);
				    object.put("user_zh",user_zh);
				    object.put("user_pwd",user_pwd);
				    object.put("user_ip",get_ip());
				    JSONObject object_post = new JSONObject();
				    object_post = Connect.post(object);
				    if(object_post != null) {
				    	if(object_post.get("status").toString().equals("true")) {
							password_hint.setText("");
							account_hint.setText("");
							usr_id=Integer.parseInt(object_post.get("id").toString());
							usr_name=object_post.get("account").toString();
							dialog.dispose();
							String[] a=null;
							Test.main(a);
							Alert.main("��½�ɹ�!");
						}else{
							if(object_post.get("massage") != null) {
								if(object_post.get("error_code").toString().equals("2")){
									password_hint.setText(object_post.get("massage").toString());
								}else {
									account_hint.setText(object_post.get("massage").toString());
								}
							}else {
								account_hint.setText("����������");
							}
						}
				    }else {
				    	account_hint.setText("����������");
				    }
					
				}else{
					password_hint.setText("������8~18λ��ĸ�������");
				}
			}else{
				account_hint.setText("�˺���6~12λ�������");
			}
		}
		public void mouseEntered(MouseEvent e) {
			
			}
		public void mouseExited(MouseEvent e) {
			
			}
		public void mousePressed(MouseEvent e) {

			}
		public void mouseReleased(MouseEvent e) {

			}
	}
	public static String get_ip() {
		InetAddress ia=null;
		String localip="";
		try {
			ia=InetAddress.getLocalHost();
			localip=ia.getHostAddress();
			} catch (UnknownHostException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		return localip;
	  }
}
