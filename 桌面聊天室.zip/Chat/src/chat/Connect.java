package chat;


import java.net.*;
import java.io.*;
import net.sf.json.JSONObject;

public class Connect {
	public static String ip="";
	public static int post_set=0;
	public static String serverName="192.168.1.104";
	public static int port=10001;
	public static void main(String[] args) {
		//System.out.println(post(null));
    }
	
	public static void set(String s,int p) {
		if(ip != null && post_set != 0 ) {
			serverName=ip;
			port=post_set;
		}else {
			serverName=s;
			port=p;
		}
	}
	public static JSONObject post(JSONObject object) {
		JSONObject postjsonObject = null;
		try
		{
			
			Socket client = new Socket(serverName, port);
		   //System.out.println("Զ��������ַ��" + client.getRemoteSocketAddress());
		   OutputStream outToServer = client.getOutputStream();
		   DataOutputStream out = new DataOutputStream(outToServer);
		   out.writeUTF(object.toString());
		   //д�뷢�͵�����
		   InputStream inFromServer = client.getInputStream();
		   DataInputStream in = new DataInputStream(inFromServer);
		   //��ȡ��Ӧ����
		   String post_str = in.readUTF();
           //System.out.println(post_str);
		   postjsonObject = JSONObject.fromObject(post_str);
           
		   //System.out.println("��������Ӧ�� " + in.readUTF());
		   client.close();
		}catch(IOException e)
		{
		   //e.printStackTrace();
		}
		return postjsonObject;
	}

}
