package chat;


import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class Set extends JFrame {

	private JPanel contentPane;
	private static JTextField ip;
	private static JTextField post;
	private final Action action = new SwingAction();
	public static int screenWidth=Login.getsize().width;
	//��Ļ����
	public static int screenHeight=Login.getsize().height;
	//��Ļ�߶�
	public static int boxWidth=380;
	//�����
	public static int boxHeight=240;
	public static Set frame = new Set();
	//��߶�
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					frame.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					frame.setResizable(false);
					frame.setVisible(true);
					ip.setText(Connect.serverName);
					post.setText(Connect.port+"");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Set() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((screenWidth-boxWidth)/2, (screenHeight-boxHeight)/2, 378, 241);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u670D\u52A1\u5668IP:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		lblNewLabel.setBounds(70, 25, 50, 30);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("\u7AEF\u53E3:");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(70, 65, 50, 30);
		contentPane.add(label);
		
		ip = new JTextField();
		ip.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		ip.setBounds(130, 25, 150, 30);
		contentPane.add(ip);
		ip.setColumns(10);
		
		post = new JTextField();
		post.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		post.setColumns(10);
		post.setBounds(130, 65, 150, 30);
		contentPane.add(post);
		
		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.setAction(action);
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		btnNewButton.setBounds(70, 132, 210, 45);
		contentPane.add(btnNewButton);
	}
	
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "����");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			String set_ip= ip.getText().trim();
			String set_port= post.getText().trim();
			if(set_ip.matches(Login.ip) && set_port.matches(Login.port)) {
				Connect.ip=set_ip;
				Connect.port=Integer.parseInt(set_port);
				Connect.set(set_ip,Integer.parseInt(set_port));
				//System.out.println(Connect.ip+Connect.port);
				Alert.main("�ɹ���");
				frame.dispose();
			}else {
				Alert.main("ʧ�ܣ�");
			}
		}
	}
}
