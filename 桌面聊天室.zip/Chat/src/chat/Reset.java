package chat;


import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.sf.json.JSONObject;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

import javax.swing.JButton;

import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.Action;

public class Reset extends JFrame {

	private JPanel contentPane;
	private JTextField account;
	private JPasswordField password;
	private JTextField email;
	private JTextField safecode;
	public int boxWidth=354;
	//��½�����
	public int boxHeight=495;
	//��½��߶�
	private final Action send_email = new to_send_email();
	private final Action resend = new to_resend();
	JLabel account_hint = new JLabel("\u8D26\u53F7\u4E3A6-12\u4F4D\u6570\u5B57");
	JLabel email_hint = new JLabel("\u6CE8\u518C\u65F6\u586B\u5199\u7684\u90AE\u7BB1");
	JLabel safe_hint = new JLabel("\u8BF7\u90AE\u7BB1\u6536\u5230\u7684\u5B89\u5168\u7801");
	JLabel password_hint = new JLabel("8~18\u4F4D\u5B57\u6BCD\u6570\u5B57\u7EC4\u5408");
	JLabel safe_label = new JLabel("\u5B89\u5168\u7801\uFF1A");
	JButton repost = new JButton("\u91CD\u53D1");
	JLabel password_label = new JLabel("\u5BC6\u7801\uFF1A");
	JButton send = new JButton("\u53D1\u9001\u9A8C\u8BC1\u90AE\u4EF6");
	JButton reset_button = new JButton("\u66F4\u6539\u5BC6\u7801");
	private final Action reset_action = new to_reset();
	public int i=30;
	static Reset frame = new Reset();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					frame.setResizable(false);
					frame.setTitle("�һ�����");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reset() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds((Login.screenWidth-boxWidth)/2, (Login.screenHeight-boxHeight)/2, boxWidth, boxHeight);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u8D26\u53F7\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label.setBounds(85, 45, 50, 30);
		contentPane.add(label);
		
		account = new JTextField();
		account.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account.setColumns(10);
		account.setBounds(135, 45, 120, 30);
		contentPane.add(account);
		
		
		account_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		account_hint.setBounds(135, 75, 120, 30);
		contentPane.add(account_hint);
		
		JLabel label_6 = new JLabel("\u90AE\u7BB1\uFF1A");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		label_6.setBounds(85, 105, 50, 30);
		contentPane.add(label_6);
		
		email = new JTextField();
		email.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		email.setColumns(10);
		email.setBounds(135, 105, 120, 30);
		contentPane.add(email);
		

		email_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		email_hint.setBounds(135, 135, 120, 30);
		contentPane.add(email_hint);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 10, 10);
		contentPane.add(panel);
		
		
		safe_label.setEnabled(false);
		safe_label.setHorizontalAlignment(SwingConstants.RIGHT);
		safe_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		safe_label.setBounds(75, 165, 60, 30);
		contentPane.add(safe_label);
		
		safecode = new JTextField();
		safecode.setEnabled(false);
		safecode.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		safecode.setColumns(10);
		safecode.setBounds(135, 165, 120, 30);
		contentPane.add(safecode);
		
		repost.setAction(resend);
		repost.setEnabled(false);
		repost.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		repost.setBounds(255, 165, 60, 30);
		repost.setFocusPainted(false);
		contentPane.add(repost);
		
		
		safe_hint.setEnabled(false);
		safe_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		safe_hint.setBounds(135, 195, 120, 30);
		contentPane.add(safe_hint);
		
		password_label.setEnabled(false);
		password_label.setHorizontalAlignment(SwingConstants.RIGHT);
		password_label.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password_label.setBounds(85, 228, 50, 30);
		contentPane.add(password_label);
		
		password = new JPasswordField();
		password.setEnabled(false);
		password.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password.setBounds(135, 225, 120, 30);
		contentPane.add(password);
		
		password_hint.setEnabled(false);
		password_hint.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		password_hint.setBounds(135, 255, 120, 30);
		contentPane.add(password_hint);
		
		
		send.setAction(send_email);
		send.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		send.setBounds(85, 340, 170, 40);
		send.setVisible(true);
		send.setFocusPainted(false);
		contentPane.add(send);
		reset_button.setAction(reset_action);
		
		
		reset_button.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		reset_button.setBounds(85, 340, 170, 40);
		reset_button.setVisible(false);
		reset_button.setFocusPainted(false);
		contentPane.add(reset_button);
		/*
		JLabel label_8 = new JLabel("");
		label_8.setIcon(new ImageIcon("img/Penguin_137.64383561644px_546496_easyicon.net.png"));
		label_8.setBounds(0, 85, 150, 170);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon("img/register.jpg"));
		label_9.setBounds(0, 0, 346, 461);
		contentPane.add(label_9);
		*/
	}
	private class to_send_email extends AbstractAction {
		public to_send_email() {
			putValue(NAME, "������֤�ʼ�");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			//Alert.main("�������óɹ�!");
			if(send_email()) {
				Timer timer = new Timer();
				timer.schedule(new TimerTask() {
			        public void run() {
			            repost.setText(i+"s");
			            repost.setEnabled(false);
			            i--;
			            if(i <= 0) {
			            	repost.setText("�ط�");
				            repost.setEnabled(true);
			            	this.cancel();
			            }
			        }
				}, 0 , 1000);
			}
		}
	}
	private class to_resend extends AbstractAction {
		public to_resend() {
			putValue(NAME, "�ط�");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			send_email();
		}
	}
	private class to_reset extends AbstractAction {
		public to_reset() {
			putValue(NAME, "��������");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String user_zh= account.getText().trim();
			
			String user_pwd = new String(password.getPassword());
			
			String user_safecode = new String(safecode.getText().trim());
			
			String user_email = email.getText().trim();
			
			if(user_zh.matches(Login.zh)) {
				account_hint.setForeground(Color.black);
				if(user_email.matches(Login.email)) {
					email_hint.setText("ע��ʱ��д������");
					email_hint.setForeground(Color.black);
					if(user_safecode.matches(Login.code)) {
						if(user_pwd.matches(Login.pwd)) {
							password_hint.setText("8~18λ��ĸ�������");
							password_hint.setForeground(Color.black);
							
							
							JSONObject object = new JSONObject();
						    object.put("action",4);
						    object.put("user_zh",user_zh);
						    object.put("user_safecode",user_safecode);
						    object.put("user_pwd",user_pwd);
						    
						    JSONObject object_post = new JSONObject();
						    object_post = Connect.post(object);
						    if(object_post != null) {
						    	if(object_post.get("status").toString().equals("true")) {
							    	//������ĳɹ�
							    	Alert.main("������ĳɹ�!");
							    	frame.dispose();
							    }else {
							    	if(object_post.get("massage") != null) {
							    		if(object_post.get("error_code").toString().equals("2")){
							    			safe_hint.setText(object_post.get("massage").toString());
							    			safe_hint.setForeground(Color.RED);
							    		}else {
							    			account_hint.setText(object_post.get("massage").toString());
											account_hint.setForeground(Color.RED);
							    		}
									}else {
										account_hint.setText("����������");
										account_hint.setForeground(Color.RED);
									}
							    }
						    }else {
						    	account_hint.setText("����������");
								account_hint.setForeground(Color.RED);
						    }
						}else {
							password_hint.setText("8~18λ��ĸ�������");
							password_hint.setForeground(Color.RED);
						}
					}else {
						safe_hint.setText("��֤�����");
						safe_hint.setForeground(Color.RED);
					}
				}else {
					email_hint.setText("�����ʽ����");
					email_hint.setForeground(Color.RED);
				}
			}else {
				account_hint.setText("�˺�Ϊ6~12λ����");
				account_hint.setForeground(Color.RED);
			}
		}
	}
	public boolean send_email() {
		// TODO Auto-generated method stub
		boolean send_email_status=false;
		
		String user_zh= account.getText().trim();
		
		String user_pwd = new String(password.getPassword());
		
		String user_safecode = new String(safecode.getText().trim());
		
		String user_email = email.getText().trim();
		if(user_zh.matches(Login.zh)) {
			account_hint.setForeground(Color.black);
			if(user_email.matches(Login.email)) {
				email_hint.setText("ע��ʱ��д������");
				email_hint.setForeground(Color.black);
				JSONObject object = new JSONObject();
			    object.put("action",3);
			    object.put("user_zh",user_zh);
			    object.put("user_email",user_email);
			    JSONObject object_post = new JSONObject();
			    object_post = Connect.post(object);
			    if(object_post != null) {
			    	if(object_post.get("status").toString().equals("true")) {
				    	//�ʼ����ͳɹ�
				    	account.setEnabled(false);
				    	email.setEnabled(false);
				    	safe_label.setEnabled(true);
				    	safecode.setEnabled(true);
				    	safe_hint.setEnabled(true);
				    	repost.setEnabled(true);
				    	password_label.setEnabled(true);
				    	password.setEnabled(true);
				    	password_hint.setEnabled(true);
				    	send.setVisible(false);
				    	reset_button.setVisible(true);
				    	send_email_status=true;
				    	
				    }else {
				    	if(object_post.get("massage") != null) {
				    		if(object_post.get("error_code").toString().equals("3")){
				    			email_hint.setText(object_post.get("massage").toString());
				    			email_hint.setForeground(Color.RED);
				    		}else {
				    			account_hint.setText(object_post.get("massage").toString());
								account_hint.setForeground(Color.RED);
				    		}
						}else {
							account_hint.setText("����������");
							account_hint.setForeground(Color.RED);
						}
				    }
			    }else {
			    	account_hint.setText("����������");
					account_hint.setForeground(Color.RED);
			    }
			    
			}else {
				email_hint.setText("�����ʽ����");
				email_hint.setForeground(Color.RED);
			}
		}else {
			account_hint.setText("�˺�Ϊ6~12λ����");
			account_hint.setForeground(Color.RED);
		}
		return send_email_status;
	}
		
	
}
