package chat;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import net.sf.json.JSONObject;
public class Test extends JFrame {

	private JPanel contentPane;
	static JTextArea content = new JTextArea();
	static JTextArea textArea = new JTextArea();
	// ����һ�� JList ʵ��
    final static JList<String> list = new JList<String>();
    private final Action action = new SwingAction();
    static String onchecked;
    static int i=0;
    public static int boxWidth=750;
	//��������
	public static int boxHeight=500;
	//�����߶�
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					//System.out.println(jsonObject);
					Test frame = new Test();
					frame.setResizable(false);
					frame.setVisible(true);
					frame.setTitle(Login.usr_name);
					list.setListData(get_online());
			        // ����Ĭ��ѡ����
			        list.setSelectedIndex(0);
			        
			        Timer timer = new Timer();
					timer.schedule(new TimerTask() {
				        public void run() {
				        	// ����ѡ������(�ڲ����Զ���װ�� ListModel )
				        	onchecked=get_list();
				        	list.setListData(get_online());
				        	boolean s=false;
				        	for(int j=0;j<list.getModel().getSize();j++) {
				        		if(onchecked.equals(list.getModel().getElementAt(j))){
				        			list.setSelectedIndex(j);
				        			s=true;
				        		}
				        	}
				        	if(!s) {
				        		list.setSelectedIndex(0);
				        	}
				        	get_content();

				        	//System.out.println(i++);
				        	
				        	//this.cancel();

				        }
					}, 0 , 500);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static String[] get_online() {
		
		JSONObject object = new JSONObject();
		object.put("action",5);
	    object.put("user_id",Login.usr_id);
	    JSONObject object_post = new JSONObject();
	    object_post = Connect.post(object);
	    //System.out.println(object_post);
	    String[] online_user=null;
	    if(object_post != null) {
	    	if(object_post.get("status").toString().equals("true")) {
	    		online_user=new String[Integer.parseInt(object_post.get("count").toString())];
	    		for(int m=0;m<Integer.parseInt(object_post.get("count").toString());m++) {
	    			//System.out.println(object_post.get(m+"").toString());
	    			online_user[m]= object_post.get(m+"").toString();
	    		}
	    	}else {
	    		online_user=new String[1];
		    	online_user[0]="Ⱥ";
		    }
	    }else {
	    	online_user=new String[1];
	    	online_user[0]="Ⱥ";
	    }
	    //System.out.println(online_user);
	    return online_user;
	}

	public static String get_list() {
		ListModel<String> listModel = list.getModel();
		int index=list.getSelectedIndex();
		listModel.getElementAt(index);
		return listModel.getElementAt(index);
	}
	public static void get_content() {
		JSONObject object = new JSONObject();
		object.put("action",7);
	    object.put("usr_id",Login.usr_id);
	    object.put("to_id",get_list());
	    JSONObject object_post = new JSONObject();
	    object_post = Connect.post(object);
	    if(object_post != null) {
	    	if(object_post.get("status").toString().equals("true")) {
	    		content.setText("");
	    		for(int m=0;m<Integer.parseInt(object_post.get("count").toString());m++) {
	    			content.setText(content.getText()+"\n"+object_post.get(m+"").toString());
	    		}
	    	}
	    }
			
	}
	/**
	 * Create the frame.
	 */
	public Test() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds((Login.screenWidth-boxWidth)/2, (Login.screenHeight-boxHeight)/2, boxWidth, boxHeight);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(164, 0, 570, 310);
		contentPane.add(scrollPane);
		content.setEnabled(false);
		content.setLineWrap(true);
		content.setDisabledTextColor(Color.black);
		scrollPane.setViewportView(content);
		 
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(164, 310, 570, 151);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton = new JButton("\u53D1\u9001");
		btnNewButton.setAction(action);
		btnNewButton.setFont(new Font("΢���ź�", Font.BOLD, 12));
		btnNewButton.setBounds(460, 108, 100, 30);
		panel_1.add(btnNewButton);
		
		
		textArea.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		textArea.setBounds(0, 0, 570, 104);
		panel_1.add(textArea);
		

		
		
		
		

        // ����һ����ѡ��С
        //list.setPreferredSize(new Dimension(200, 100));

        // ������ѡ
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        /*
        // ����ѡ��ѡ��״̬���ı�ļ�����
        list.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
            	content.setText("");
        		get_content();
            }
        });
        */
        
        list.setFont(new Font("΢���ź�", Font.PLAIN, 12));
		list.setBounds(0, 0, 163, 461);
		list.setBackground(new Color(230,230,230));
		contentPane.add(list);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "����");
			//putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			JSONObject object = new JSONObject();
			object.put("action",6);
		    object.put("send_user_id",Login.usr_id);
		    object.put("to_user_id",get_list());
		    object.put("content",textArea.getText());
		    JSONObject object_post = new JSONObject();
		    object_post = Connect.post(object);
		    if(object_post != null) {
		    	if(object_post.get("status").toString().equals("true")) {
		    		textArea.setText("");
		    		//System.out.println("1111");
		    	}
		    	
		    }
		}
	}
}
