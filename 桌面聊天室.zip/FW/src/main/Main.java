package main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import net.sf.json.JSONObject;

public class Main extends Thread {
	private ServerSocket serverSocket;
	// JDBC �����������ݿ� URL
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/Chat?characterEncoding=utf8&useSSL=true&serverTimezone=UTC";

	// ���ݿ���û��������룬��Ҫ�����Լ�������
	static final String USER = "root";
	static final String PASS = "111111";

	public static final String KEY_SHA = "SHA";
	public static String format = "yyyy-MM-dd HH:mm:ss";
	public static SimpleDateFormat sdf = new SimpleDateFormat(format);

	public Main(int port) throws IOException {
		serverSocket = new ServerSocket(port);
		System.out.println("���������ɹ�...");
		System.out.println("������ַΪ:" + get_ip());
		System.out.println("�˿ں�Ϊ:" + serverSocket.getLocalPort());
		// serverSocket.setSoTimeout(100000);
		run();
	}

	public void run() {
		while (true) {
			try {

				Socket server = serverSocket.accept();

				DataInputStream in = new DataInputStream(server.getInputStream());
				String post_str = in.readUTF();
				// System.out.println(post_str);
				JSONObject jsonObject = JSONObject.fromObject(post_str);
				int i = 0;
				if (jsonObject.get("action") != null) {
					i = (int) jsonObject.get("action");
				}

				JSONObject post = doaction(i, jsonObject, server.getRemoteSocketAddress().toString(),
						serverSocket.getLocalPort());
				DataOutputStream out = new DataOutputStream(server.getOutputStream());
				out.writeUTF(post.toString());

				server.close();
			} catch (SocketTimeoutException s) {
				// System.out.println("Socket timed out!");
				break;
			} catch (IOException e) {
				// e.printStackTrace();
				break;
			}
		}
	}

	private JSONObject doaction(int i, JSONObject jsonObject, String user_ip, int user_port) {
		// System.out.println(i);
		/**
		 * 1 ����½ 2��ע�� 3���һ�����--�ʼ� 4���һ�����--�������� 5��online--user 6��������Ϣ 7������--����
		 **/

		JSONObject object = new JSONObject();
		if (i == 1) {

			String sql = "SELECT * FROM user where account ='" + jsonObject.get("user_zh") + "'";
			String[][] user = get_one_by_sql(sql);
			// if(user[])
			if (user.length > 0) {
				if (user[0][9].equals("0")) {
					String pwd_SHA = getSHA(jsonObject.get("user_pwd").toString());
					if (pwd_SHA.equals(user[0][2])) {
						// System.out.println("�ɹ���");
						if (Login(user[0][0], user_ip, user_port)) {
							object.put("status", true);
							object.put("massage", "��½�ɹ���");
							object.put("id", user[0][0]);
							object.put("account", user[0][1]);
							object.put("email", user[0][3]);
							object.put("active_time", user[0][6]);
							String date = sdf.format(new Date());
							System.out.println(date + "\t" + "�û���" + user[0][1] + "\t" + "��½�ɹ���");
							// My.main(date+"\t"+"�û���"+user[0][1]+"\t"+"��½�ɹ���");
						} else {
							object.put("status", false);
							object.put("error_code", 0);
							object.put("massage", "��������æ��");
						}
					} else {
						object.put("status", false);
						object.put("error_code", 2);
						object.put("massage", "�������");
					}
				} else {
					object.put("status", false);
					object.put("massage", "�˺���ʧЧ��");
					object.put("error_code", 1);
				}
			} else {
				object.put("status", false);
				object.put("massage", "�˺Ų����ڣ�");
				object.put("error_code", 1);
			}
		} else if (i == 2) {
			String insert_pwd_SHA = getSHA(jsonObject.get("user_pwd").toString());
			String register_select_sql = "SELECT * FROM user where account ='" + jsonObject.get("user_zh") + "'";
			String[][] user = get_one_by_sql(register_select_sql);
			if (user.length > 0) {
				object.put("status", false);
				object.put("massage", "�˺��ѱ�ע�ᣡ");
			} else {
				String register_insert_sql = "INSERT INTO `Chat`.`user`(`account`,`password`,`email`,`login_ip`,`login_post`) VALUES ('"
						+ jsonObject.get("user_zh") + "','" + insert_pwd_SHA + "','" + jsonObject.get("user_email")
						+ "','" + jsonObject.get("user_ip") + "','" + jsonObject.get("user_port") + "')";
				if (update_by_sql(register_insert_sql)) {
					object.put("status", true);
					object.put("massage", "ע��ɹ���");
					String date = sdf.format(new Date());
					System.out.println(date + "\t" + "�û���" + jsonObject.get("user_zh") + "\t" + "ע��ɹ���");
					// My.main(date+"\t"+"�û���"+jsonObject.get("user_zh")+"\t"+"ע��ɹ���");
				} else {
					object.put("status", false);
					object.put("massage", "ע��ʧ�ܣ�");
				}
			}
		} else if (i == 3) {
			String reset_send_select_sql = "SELECT * FROM user where account ='" + jsonObject.get("user_zh") + "'";
			String[][] user = get_one_by_sql(reset_send_select_sql);
			if (user.length > 0) {
				if (user[0][3].toString().equals(jsonObject.get("user_email").toString())) {
					String safe_code = getsafecode(6);
					Boolean email_status = Email.send_163(user[0][3].toString(), "��ȫ��֤",
							"�������һ���������;��ȫ��Ϊ" + safe_code + "�벻Ҫ�������ˣ��Ǳ��˲����ɺ���");
					if (!email_status) {
						email_status = Email.send_qq(user[0][3].toString(), "��ȫ��֤",
								"�������һ���������;��ȫ��Ϊ" + safe_code + "�벻Ҫ�������ˣ��Ǳ��˲����ɺ���");
						if (!email_status) {
							object.put("status", false);
							object.put("massage", "�ʼ�����ʧ�ܣ�");
							object.put("error_code", 3);
						}
					}
					if (email_status) {
						int time = get_time() + 300;
						String email_reset_sql = "UPDATE `Chat`.`user` SET `safe_code`='" + safe_code
								+ "',`safe_time`='" + time + "' where id='" + user[0][0].toString() + "' ";
						if (update_by_sql(email_reset_sql)) {
							object.put("status", true);
							object.put("massage", "�ʼ����ͳɹ���");
							object.put("error_code", 0);
						}
					}
				} else {
					object.put("status", false);
					object.put("massage", "�������");
					object.put("error_code", 3);
				}
			} else {
				object.put("status", false);
				object.put("massage", "�˺Ų����ڣ�");
				object.put("error_code", 2);
			}
		} else if (i == 4) {
			String time = get_time().toString();
			String reset_select_sql = "SELECT * FROM user where account ='" + jsonObject.get("user_zh") + "' ";
			String[][] user = get_one_by_sql(reset_select_sql);
			if (user.length > 0) {
				if (user[0][7].toString().equals(jsonObject.get("user_safecode").toString())) {
					if (user[0][8].compareTo(time) >= 0) {
						String reset_pwd_SHA = getSHA(jsonObject.get("user_pwd").toString());
						String password_reset_sql = "UPDATE `Chat`.`user` SET `password`='" + reset_pwd_SHA
								+ "' where id='" + user[0][0].toString() + "' ";
						if (update_by_sql(password_reset_sql)) {
							object.put("status", true);
							object.put("massage", "�������óɹ���");
							object.put("error_code", 0);
						}
					} else {
						object.put("status", false);
						object.put("massage", "��ȫ���ѹ��ڣ�");
						object.put("error_code", 2);
					}
				} else {
					object.put("status", false);
					object.put("massage", "��ȫ�����");
					object.put("error_code", 2);
				}
			}
		} else if (i == 5) {
			// System.out.println(jsonObject);
			String time = get_time().toString();
			String online_select_sql = "SELECT * FROM user where active_time >'" + time + "' and id <> '"
					+ jsonObject.get("user_id") + "' ";
			String[][] online = get_one_by_sql(online_select_sql);
			if (online.length > 0) {
				object.put("status", true);
				object.put("count", online.length + 1);
				object.put(0, "Ⱥ");
				for (int m = 1; m <= online.length; m++) {
					object.put(m, online[m - 1][1]);
				}

			} else {
				object.put("status", true);
				object.put("count", 1);
				object.put(0, "Ⱥ");
			}
			return object;
		} else if (i == 6) {
			// System.out.println(jsonObject);
			String time = get_time().toString();
			String to_user = "";
			String to_user_f = "";
			if (jsonObject.get("to_user_id").toString().equals("Ⱥ")) {
				to_user = "Ⱥ";
				String chat_insert_sql = "INSERT INTO `Chat`.`chat`(`send_user`,`to_user`,`type`,`content`,`time`) VALUES ('"
						+ get_username_by_id(jsonObject.get("send_user_id").toString()) + "','All','1','"
						+ jsonObject.get("content") + "','" + time + "')";
				if (update_by_sql(chat_insert_sql)) {
					object.put("status", true);
				} else {
					object.put("status", false);
				}
				to_user_f = "Ⱥ";
			} else {
				to_user = jsonObject.get("to_user_id").toString();
				String chat_send_select_sql = "SELECT * FROM user where account ='" + jsonObject.get("to_user_id")
						+ "' ";
				String[][] chat_send = get_one_by_sql(chat_send_select_sql);
				if (chat_send.length > 0) {
					String chat_insert_sql = "INSERT INTO `Chat`.`chat`(`send_user`,`to_user`,`type`,`content`,`time`) VALUES ('"
							+ get_username_by_id(jsonObject.get("send_user_id").toString()) + "','"
							+ chat_send[0][1].toString() + "','0','" + jsonObject.get("content") + "','" + time + "')";
					to_user_f = chat_send[0][1].toString();
					if (update_by_sql(chat_insert_sql)) {
						object.put("status", true);
					} else {
						object.put("status", false);
					}
				}
			}
			String date = sdf.format(new Date());

			System.out.println(date + "\t" + "�û���" + get_username_by_id(jsonObject.get("send_user_id").toString())
					+ "\t" + "��" + to_user_f + "����\t" + jsonObject.get("content").toString() + "\t�ɹ���");
			My.main(date + "\t" + "�û���" + get_username_by_id(jsonObject.get("send_user_id").toString()) + "\t" + "��"
					+ to_user_f + "����\t" + jsonObject.get("content").toString() + "\t�ɹ���");
		} else if (i == 7) {
			// System.out.println(jsonObject);
			// String time=get_time().toString();
			String content = null;

			keep_online(jsonObject.get("usr_id").toString());
			if (jsonObject.get("to_id").toString().equals("Ⱥ")) {
				String chat_select_sql = "SELECT * FROM chat where  to_user = 'All' order by time asc limit 100";
				String[][] chat = get_chat_by_sql(chat_select_sql);
				if (chat.length > 0) {
					object.put("status", true);
					object.put("count", chat.length);
					for (int m = 0; m < chat.length; m++) {
						String date = sdf.format(new Date(Long.valueOf(chat[m][5] + "000")));
						content = chat[m][1] + "\t" + date + "\t" + chat[m][4];
						object.put(m, content);
					}
				} else {
					object.put("status", false);
				}
			} else {
				String chat_select_sql = "SELECT * FROM chat where (send_user ='"
						+ get_username_by_id(jsonObject.get("usr_id").toString()) + "' and to_user = '"
						+ jsonObject.get("to_id") + "') or (send_user ='" + jsonObject.get("to_id")
						+ "' and to_user = '" + get_username_by_id(jsonObject.get("usr_id").toString())
						+ "') order by time asc limit 100";
				String[][] chat = get_chat_by_sql(chat_select_sql);
				// System.out.println(chat_select_sql);
				if (chat.length > 0) {
					object.put("status", true);
					object.put("count", chat.length);
					for (int m = 0; m < chat.length; m++) {
						String date = sdf.format(new Date(Long.valueOf(chat[m][5] + "000")));
						content = chat[m][1] + "\t" + date + "\t" + chat[m][4];
						object.put(m, content);
					}
				} else {
					object.put("status", false);
				}
			}
			// System.out.println(object);
			return object;
		}

		// System.out.println(object);
		return object;
	}

	private static boolean Login(String id, String user_ip, int user_port) {
		// TODO �Զ����ɵķ������
		int time = get_time() + 60;
		String sql = "UPDATE `Chat`.`user` SET `login_ip` = '" + user_ip + "',`login_post`='" + user_port
				+ "',active_time='" + time + "' WHERE `id` = '" + id + "'";
		boolean status = update_by_sql(sql);
		return status;
	}

	private static boolean keep_online(String id) {
		// TODO �Զ����ɵķ������
		int time = get_time() + 60;
		String sql = "UPDATE `Chat`.`user` SET active_time='" + time + "' WHERE `id` = '" + id + "'";
		boolean status = update_by_sql(sql);
		return status;
	}

	private static String get_username_by_id(String id) {
		String[][] user = get_one_by_sql("SELECT * FROM user where id='" + id + "'");
		if (user.length > 0) {
			return user[0][1];
		} else {
			return null;
		}
	}

	private static String[][] get_one_by_sql(String sql) {
		Connection conn = null;
		Statement stmt = null;
		String[][] res = null;
		try {

			// ע�� JDBC ����
			Class.forName("com.mysql.jdbc.Driver");

			// ������
			// System.out.println("�������ݿ�...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			// ִ�в�ѯ
			// System.out.println(" ʵ����Statement����...");
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);
			// չ����������ݿ�
			int n = 0;
			rs.last();
			res = new String[rs.getRow()][];

			// System.out.println(rs.getRow());
			rs.beforeFirst();
			while (rs.next()) {
				// ͨ���ֶμ���
				res[n] = new String[10];
				res[n][0] = rs.getString("id");
				res[n][1] = rs.getString("account");
				res[n][2] = rs.getString("password");
				res[n][3] = rs.getString("email");
				res[n][4] = rs.getString("login_ip");
				res[n][5] = rs.getString("login_post");
				res[n][6] = rs.getString("active_time");
				res[n][7] = rs.getString("safe_code");
				res[n][8] = rs.getString("safe_time");
				res[n][9] = rs.getString("isdel");
				// System.out.print(id);
				// �������
				n++;

			}
			// ��ɺ�ر�
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			// ���� JDBC ����
			// se.printStackTrace();
		} catch (Exception e) {
			// ���� Class.forName ����
			// e.printStackTrace();
		} finally {
			// �ر���Դ
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // ʲô������
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				// se.printStackTrace();
			}
		}

		return res;
	}

	private static String[][] get_chat_by_sql(String sql) {
		Connection conn = null;
		Statement stmt = null;
		String[][] res = null;
		try {

			// ע�� JDBC ����
			Class.forName("com.mysql.jdbc.Driver");

			// ������
			// System.out.println("�������ݿ�...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			// ִ�в�ѯ
			// System.out.println(" ʵ����Statement����...");
			stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(sql);
			// չ����������ݿ�
			int n = 0;
			rs.last();
			res = new String[rs.getRow()][];

			// System.out.println(rs.getRow());
			rs.beforeFirst();
			while (rs.next()) {
				// ͨ���ֶμ���
				res[n] = new String[8];
				res[n][0] = rs.getString("id");
				res[n][1] = rs.getString("send_user");
				res[n][2] = rs.getString("to_user");
				res[n][3] = rs.getString("type");
				res[n][4] = rs.getString("content");
				res[n][5] = rs.getString("time");
				res[n][6] = rs.getString("isread");
				res[n][7] = rs.getString("isdel");
				// System.out.print(id);
				// �������
				n++;

			}
			// ��ɺ�ر�
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			// ���� JDBC ����
			// se.printStackTrace();
		} catch (Exception e) {
			// ���� Class.forName ����
			// e.printStackTrace();
		} finally {
			// �ر���Դ
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // ʲô������
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				// se.printStackTrace();
			}
		}

		return res;
	}

	private static boolean update_by_sql(String sql) {
		Connection conn = null;
		Statement stmt = null;
		boolean res = false;
		try {

			// ע�� JDBC ����
			Class.forName("com.mysql.jdbc.Driver");

			// ������
			// System.out.println("�������ݿ�...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// ִ�в�ѯ
			// System.out.println(" ʵ����Statement����...");
			stmt = conn.createStatement();
			int result = stmt.executeUpdate(sql);
			if (result != -1) {
				res = true;
			}
			stmt.close();
			conn.close();
		} catch (SQLException se) {
			// ���� JDBC ����
			// se.printStackTrace();
		} catch (Exception e) {
			// ���� Class.forName ����
			// e.printStackTrace();
		} finally {
			// �ر���Դ
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // ʲô������
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				// se.printStackTrace();
			}
		}
		return res;
	}

	public static String getSHA(String inputStr) {
		BigInteger sha = null;
		byte[] inputData = inputStr.getBytes();
		try {
			MessageDigest messageDigest = MessageDigest.getInstance(KEY_SHA);
			messageDigest.update(inputData);
			sha = new BigInteger(messageDigest.digest());
			// System.out.println("SHA���ܺ�:" + sha.toString(32));
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return sha.toString(32);
	}

	public String get_ip() {
		InetAddress ia = null;
		String localip = "";
		try {
			ia = InetAddress.getLocalHost();
			localip = ia.getHostAddress();
			System.out.println("������ip�� ��" + localip);
		} catch (UnknownHostException e) {
			// TODO �Զ����ɵ� catch ��
			// e.printStackTrace();
		}
		return localip;
	}

	public static String getsafecode(int length) {
		String base = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(base.length());
			sb.append(base.charAt(number));
		}
		return sb.toString();
	}

	public static Integer get_time() {
		String timestamp = String.valueOf(new Date().getTime() / 1000);
		return Integer.valueOf(timestamp);
	}

	public static void main(String[] args) {
		int port = 10001;
		// update_by_sql("UPDATE `Chat`.`user` SET `password` = '"+getSHA("admin123")+"'
		// WHERE `id` = 1");
		try {
			Thread t = new Main(port);
			t.run();
		} catch (IOException e) {
			// e.printStackTrace();
		}

	}
}