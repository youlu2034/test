package main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class My {
	public static void main(String date) {
		File file =new File("javafile.txt");
		try {
	      //if file doesnt exists, then create it
	      if(!file.exists()){
	       file.createNewFile();
	      }

	      //true = append file
	      FileWriter fileWritter = new FileWriter(file.getName(),true);
	      
	      fileWritter.write(date+"\n");
	      fileWritter.close();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			//e.printStackTrace();
		}
	     // System.out.println("Done");
		
	}
}
