package main;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class Mytest extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mytest frame = new Mytest();
					frame.setVisible(true);


				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Mytest() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(186, 228, 93, 23);
		contentPane.add(btnNewButton);
		
		JLabel ip = new JLabel("192.168.0.1");
		ip.setBounds(50, 30, 100, 30);
		contentPane.add(ip);
		
		JLabel lblNewLabel = new JLabel("IP\uFF1A");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(20, 30, 30, 30);
		contentPane.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("\u7AEF\u53E3\uFF1A");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(0, 70, 50, 30);
		contentPane.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(50, 70, 70, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u5728\u7EBF\u4EBA\u6570\uFF1A");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(160, 30, 80, 30);
		contentPane.add(label);
		
		JLabel label_2 = new JLabel("0");
		label_2.setBounds(240, 30, 30, 30);
		contentPane.add(label_2);
		
	}
	

}
