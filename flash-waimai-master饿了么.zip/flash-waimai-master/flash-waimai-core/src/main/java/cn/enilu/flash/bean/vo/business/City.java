package cn.enilu.flash.bean.vo.business;

import lombok.Data;

import java.io.Serializable;

/**
 * @author ：enilu
 * @date ：Created in 2019/10/23 22:06
 */
@Data
public class City implements Serializable {
    private Integer id;
    private String name;
    
}
