package cn.enilu.flash.bean.entity.front.sub;

import lombok.Data;

/**
 * Created  on 2018/1/7 0007.
 *
 *@Author enilu
 */
@Data
public class OrderStatusBar {
    private String color;
    private String image_type="";
    private String sub_title;
    private String title="";

}
