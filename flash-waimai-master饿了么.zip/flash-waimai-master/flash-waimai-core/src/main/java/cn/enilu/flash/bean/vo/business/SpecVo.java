package cn.enilu.flash.bean.vo.business;

import lombok.Data;

/**
 * @author ：enilu
 * @date ：Created in 2019/9/7 11:13
 */
@Data
public class SpecVo {
    private String specs;
    private String packing_fee;
    private String price;
}
