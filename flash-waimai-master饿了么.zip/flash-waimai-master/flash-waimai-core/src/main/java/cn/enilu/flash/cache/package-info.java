/**
 * package-info
 *
 * @version 2018/9/11 0011
 *@Author enilu
 */
package cn.enilu.flash.cache;