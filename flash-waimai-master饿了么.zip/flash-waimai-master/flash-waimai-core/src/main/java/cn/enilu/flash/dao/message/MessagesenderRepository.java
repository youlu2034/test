package cn.enilu.flash.dao.message;


import cn.enilu.flash.bean.entity.message.MessageSender;
import cn.enilu.flash.dao.BaseRepository;


public interface MessagesenderRepository extends BaseRepository<MessageSender,Long> {
}

