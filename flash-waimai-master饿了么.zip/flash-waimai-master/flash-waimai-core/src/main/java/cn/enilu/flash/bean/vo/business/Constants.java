package cn.enilu.flash.bean.vo.business;

/**
 * Created  on 2017/12/29 0029.
 *
 *@Author enilu
 */
public class Constants {
    public static  final String SESSION_ID="login_user_session";
    public static  final String WX_MINIAPP_TOKEN = "wx_minapp_token";
}
