package cn.enilu.flash.bean.entity.front.sub;

import lombok.Data;

/**
 * @author ：enilu
 * @date ：Created in 2019/10/24 23:21
 */
@Data
public class Tag {
    private Integer count = 0;
    private String name;
    private Boolean unsatisfied=false;
}
