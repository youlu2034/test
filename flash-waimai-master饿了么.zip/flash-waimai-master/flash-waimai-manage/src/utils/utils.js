const apiUrl = process.env.BASE_API
export function getApiUrl() {
  return apiUrl
}
