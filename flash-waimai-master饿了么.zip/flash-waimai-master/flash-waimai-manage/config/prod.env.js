'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://waimai-api.microapp.store/api"',
}
