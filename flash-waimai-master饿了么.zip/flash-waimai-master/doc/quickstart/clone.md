# 克隆本项目

本项目地址为：[https://gitee.com/microapp/flash-waimai](https://gitee.com/microapp/flash-waimai),如果对你有用，欢迎给个star

项目共三个分支分别为：
- master 项目主分支
- gh-pages 项目在线文档

进入控制台输入以下命令将项目克隆到本地：
```
git clone https://gitee.com/microapp/flash-waimai.git
```