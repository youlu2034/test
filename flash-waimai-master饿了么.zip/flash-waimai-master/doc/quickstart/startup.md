# 启动项目

## 启动flash-waimai-api
- 右键直接运行cn.enilu.flash.api.ApiApplication 类即可已启动flash-api
- 启动成功后访问http://localhost:8082/swagger-ui.html
![api](../img/flash-waimai-api.jpg)
## 启动flash-waimai-manage
- 进入flash-waimai-manage目录
    - 命令行窗口运行 npm install --registry=https://registry.npmmirror.com
    - 运行  npm run dev
    - 启动成功后访问 http://localhost:9528,登录，用户名密码:admin/admin 
 ![vue](../admin.gif)

## 启动flash-waimai-mobile
- 启动步骤和flash-waimai-manage类似，这里不再赘述
 ![h5](../mobile.gif)

so，是不是很简单!
