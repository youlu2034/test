---
home: true
heroImage: /logo.png
heroText: ''
actionText: 快速开始 →
actionLink: /base/preface
footer: MIT Licensed | Copyright © 2019-present microapp.store
---

<div style="text-align: center">
  <Bit/>
</div>

<div class="features">
  <div class="feature">
    <h2>简单快捷</h2>
    <p>基于spring boot，vuejs快速构建外卖平台</p>
  </div>
   
  <div class="feature">
    <h2>支持齐全</h2>
    <p>提供api，后台管理，包含h5。</p>
  </div>
  <div class="feature">
      <h2>最新技术栈</h2>
      <p>使用Spring Boot+JPA构建后端服务，<br>vue/element构建前端界面</p>
   </div> 
</div>
